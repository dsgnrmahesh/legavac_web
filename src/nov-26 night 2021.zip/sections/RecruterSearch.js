import React from "react";
import RecruterSearchForm from "../components/RecruterSearchForm";

export default function RecruterSearch() {
  return (
    <>
      <RecruterSearchForm />
    </>
  );
}
