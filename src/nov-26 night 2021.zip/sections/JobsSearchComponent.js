import React, { useState, useEffect } from "react";
import { Row } from "react-bootstrap";
import Pagination from "react-js-pagination";
import JobListGridItem from "../components/JobListGridItem";
import { getPostjobDetail } from "../config/api";

export default function JobsSearchComponent({ data }) {
  const [activePage, setActivePage] = useState(1);
  const handlePageChange = (pageNumber) => {
    console.log(`active page is ${pageNumber}`);
    setActivePage(pageNumber);
  };
  const companies = [
    {
      name: "Administration Coordinator",
      company: "Dthrill Software solutions pvt. ltd.",
      exp: "0-5 Yrs",
      pkg: "3,00,000 - 4,50,000 PA.",
      location: "Bangalore/Bengaluru(Museum Road)",
      qualifications:
        "Qualification: Graduate Checking required / adequate Stock on Housekeeping materials / ...",
      desc: [
        "Administration",
        "Office Administration",
        "Front Office Management",
      ],
      postedAt: "22 Days Ago",
    },
    {
      name: "Administration Coordinator",
      company: "Dthrill Software solutions pvt. ltd.",
      exp: "0-5 Yrs",
      pkg: "3,00,000 - 4,50,000 PA.",
      location: "Bangalore/Bengaluru(Museum Road)",
      qualifications:
        "Qualification: Graduate Checking required / adequate Stock on Housekeeping materials / ...",
      desc: [
        "Administration",
        "Office Administration",
        "Front Office Management",
      ],
      postedAt: "22 Days Ago",
    },
    {
      name: "Administration Coordinator",
      company: "Dthrill Software solutions pvt. ltd.",
      exp: "0-5 Yrs",
      pkg: "3,00,000 - 4,50,000 PA.",
      location: "Bangalore/Bengaluru(Museum Road)",
      qualifications:
        "Qualification: Graduate Checking required / adequate Stock on Housekeeping materials / ...",
      desc: [
        "Administration",
        "Office Administration",
        "Front Office Management",
      ],
      postedAt: "22 Days Ago",
    },
    {
      name: "Administration Coordinator",
      company: "Dthrill Software solutions pvt. ltd.",
      exp: "0-5 Yrs",
      pkg: "3,00,000 - 4,50,000 PA.",
      location: "Bangalore/Bengaluru(Museum Road)",
      qualifications:
        "Qualification: Graduate Checking required / adequate Stock on Housekeeping materials / ...",
      desc: [
        "Administration",
        "Office Administration",
        "Front Office Management",
      ],
      postedAt: "22 Days Ago",
    },
    {
      name: "Administration Coordinator",
      company: "Dthrill Software solutions pvt. ltd.",
      exp: "0-5 Yrs",
      pkg: "3,00,000 - 4,50,000 PA.",
      location: "Bangalore/Bengaluru(Museum Road)",
      qualifications:
        "Qualification: Graduate Checking required / adequate Stock on Housekeeping materials / ...",
      desc: [
        "Administration",
        "Office Administration",
        "Front Office Management",
      ],
      postedAt: "22 Days Ago",
    },
    {
      name: "Administration Coordinator",
      company: "Dthrill Software solutions pvt. ltd.",
      exp: "0-5 Yrs",
      pkg: "3,00,000 - 4,50,000 PA.",
      location: "Bangalore/Bengaluru(Museum Road)",
      qualifications:
        "Qualification: Graduate Checking required / adequate Stock on Housekeeping materials / ...",
      desc: [
        "Administration",
        "Office Administration",
        "Front Office Management",
      ],
      postedAt: "22 Days Ago",
    },
    {
      name: "Administration Coordinator",
      company: "Dthrill Software solutions pvt. ltd.",
      exp: "0-5 Yrs",
      pkg: "3,00,000 - 4,50,000 PA.",
      location: "Bangalore/Bengaluru(Museum Road)",
      qualifications:
        "Qualification: Graduate Checking required / adequate Stock on Housekeeping materials / ...",
      desc: [
        "Administration",
        "Office Administration",
        "Front Office Management",
      ],
      postedAt: "22 Days Ago",
    },
  ];
  return (
    <>
      <Row className="app__jobLists">
        {data ? (
          data.map((company, idx) => (
            <JobListGridItem data={company} sm={12} md={12} lg={12} key={idx} />
          ))
        ) : (
          <></>
        )}
      </Row>
      <Pagination
        activePage={activePage}
        itemsCountPerPage={9}
        totalItemsCount={90}
        pageRangeDisplayed={5}
        onChange={handlePageChange.bind(this)}
      />
    </>
  );
}
