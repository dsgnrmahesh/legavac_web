import { mdiDownload } from "@mdi/js";
import Icon from "@mdi/react";
import React, { useState, useEffect } from "react";
import { Col, Row } from "react-bootstrap";
import { getCandidateDetailByID } from "../config/api";
import { ReactSession } from "react-client-session";

export default function PersonalInfotation() {
  const [state, setState] = useState({
    CandidateID: "0",
    FirstName: "",
    MiddleName: "",
    LastName: "",
    Mobile: "",
    EmailID: "",
    Password: "",
    Dateofbirth: "",
    GenderID: "",
    Gender: "",
    Hometown: "",
    Pincode: "",
    WorkpermitforUSA: "",
    Workpermitforothercountry: "",
    CommunityID: "",
    Resumepath: "",
    WorkExpInY: "0",
    WorkExpInM: "0",
  });
  useEffect(() => {
    setState({ ...state, CandidateID: sessionStorage.getItem("CandidateID") });
    if (sessionStorage.getItem("CandidateID") !== "0") {
      CandidateDetailByID();
    }
  }, []);
  async function CandidateDetailByID() {
    await getCandidateDetailByID(sessionStorage.getItem("CandidateID"))
      .then((response) => {
        if (response[0].length > 0) {
          setState(response[0][0]);
        }
        //alert(response[0][0]);
        //ResetState();
        //setRedirect(true);
      })
      .catch((error) => {
        alert(error);
      });
  }
  const years = [];
  for (var i = 0; i <= 31; i++) {
    if (i === 0) years.push("select");
    else years.push(i - 1);
  }
  const handleChange = (e) => {
    if (e.target.name === "mobile") {
      if (/^\d+$/.test(e.target.value)) {
        setState({ ...state, [e.target.name]: e.target.value });
      } else {
        return false;
      }
    }
  };
  const renderYearsOptions = years.map((year) => (
    <option value={year} key={year}>
      {year}
    </option>
  ));
  return (
    <>
      <div className="profileBoxDetails">
        <div className="profileBoxDetailInner">
          <div className="profileForm">
            <Row className="justify-content-between">
              <Col sm={12} md={5}>
                <div className="mb-3">
                  <label className="frmLabel text-start mb-1 float-none">
                    First Name
                  </label>
                  <input
                    type="text"
                    className="frmInput"
                    value={state.FirstName}
                    readOnly
                  />
                </div>
              </Col>
              <Col sm={12} md={5}>
                <div className="mb-3">
                  <label className="frmLabel text-start mb-1 float-none">
                    Last Name
                  </label>
                  <input
                    type="text"
                    className="frmInput"
                    value={state.LastName}
                    readOnly
                  />
                </div>
              </Col>
              <Col sm={12} md={5}>
                <div className="mb-3">
                  <label className="frmLabel text-start mb-1 float-none">
                    Mobile Number
                  </label>
                  <div className="d-flex">
                    <input
                      type="text"
                      defaultValue="+91"
                      className="frmInput mb-2 me-3"
                      disabled
                      autoComplete="off"
                      style={{
                        width: "70px",
                        textAlign: "right",
                        cursor: "not-allowed",
                      }}
                    />
                    <input
                      type="text"
                      name="mobile"
                      placeholder="Enter Mobile Number"
                      className="frmInput mb-2"
                      onChange={handleChange}
                      maxLength="10"
                      value={state.Mobile}
                      autoComplete="off"
                      readOnly
                    />
                  </div>
                </div>
              </Col>
              <Col sm={12} md={5}>
                <div className="mb-3">
                  <label className="frmLabel text-start mb-1 float-none">
                    Total Work Experience
                  </label>
                  <div className="d-flex mb-2 pb-1">
                    <div className="d-flex align-items-center me-4">
                      <select
                        className="frmInput w-auto mb-0"
                        value={state.WorkExpInY}
                        disabled
                      >
                        {renderYearsOptions}
                      </select>
                      <p className="frmText mb-0">Year(s)</p>
                    </div>
                    <div className="d-flex align-items-center me-4">
                      <select
                        className="frmInput w-auto mb-0"
                        value={state.WorkExpInM}
                        disabled
                      >
                        <option>0</option>
                        <option>1</option>
                        <option>2</option>
                        <option>3</option>
                        <option>4</option>
                        <option>5</option>
                        <option>6</option>
                        <option>7</option>
                        <option>8</option>
                        <option>9</option>
                        <option>10</option>
                        <option>11</option>
                      </select>
                      <p className="frmText mb-0">Month(s)</p>
                    </div>
                  </div>
                </div>
              </Col>
            </Row>
            <Row>
              <Col sm={12} md={5}>
                <div className="mb-3">
                  <label className="frmLabel text-start mb-1 float-none">
                    Resume
                  </label>
                  <div className="uploadedFile">
                    <span className="d-block mb-2">
                      resume_08-sept-2021.pdf
                    </span>
                    <a
                      href="http://localhost:5000/client/uploads/resume/resume_08-sept-2021.pdf"
                      download
                    >
                      <Icon path={mdiDownload} />
                      download
                    </a>
                  </div>
                </div>
              </Col>
            </Row>
          </div>
        </div>
      </div>
    </>
  );
}
