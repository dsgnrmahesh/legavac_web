import React, { useState, useEffect } from "react";
import { Col, Row } from "react-bootstrap";
import { getCandidateEmploymentDetailByID } from "../config/api";
export default function EmploymentDetails() {
  const [state, setState] = useState({
    CandidateemploymentID: "",
    CandidateID: "",
    Companyname: "",
    JobTitle: "",
    AnnualSalaryInLakh: "",
    AnnualSalaryInThousand: "",
    JoiningDateInY: "",
    JoiningDateInM: "",
    RelivingDateInY: "",
    RelivingDateInM: "",
    City: "",
    NoticePeriod: "",
  });
  useEffect(() => {
    setState({ ...state, CandidateID: sessionStorage.getItem("CandidateID") });
    if (sessionStorage.getItem("CandidateID") !== "0") {
      CandidateEmploymentDetailByID();
    }
  }, []);
  async function CandidateEmploymentDetailByID() {
    await getCandidateEmploymentDetailByID(sessionStorage.getItem("CandidateID"))
      .then((response) => {
        if (response[0].length > 0) {
          setState(response[0][0]);
          //alert(response[0][0]);
          //ResetState();
          //setRedirect(true);
        }
      })
      .catch((error) => {
        alert(error);
      });
  }
  let years = [];
  for (var i = new Date().getFullYear(); i >= 1970; i--) {
    years.push(i);
  }
  const renderYearsOptions = years.map((year) => (
    <option value={year} key={year}>
      {year}
    </option>
  ));
  return (
    <>
      <div className="profileBoxDetails">
        <div className="profileBoxDetailInner">
          <div className="profileForm">
            <Row>
              <Col sm={12} md={12}>
                <Row className="justify-content-between">
                  <Col xs={12} md={5}>
                    <label className="frmLabel text-start mb-1 float-none">
                      Current Designation
                    </label>
                    <input
                      type="text"
                      placeholder="Enter your job title"
                      className="frmInput mb-2"
                      autoComplete="off"
                      value={state.JobTitle}
                      disabled
                    />
                  </Col>
                  <Col xs={12} md={5}>
                    <label className="frmLabel text-start mb-1 float-none">
                      Current Company
                    </label>
                    <input
                      type="text"
                      placeholder="Where you are currently working"
                      className="frmInput mb-2"
                      autoComplete="off"
                      value={state.Companyname}
                      disabled
                    />
                  </Col>
                  <Col xs={12} md={6}>
                    <label className="frmLabel text-start mb-1 float-none">
                      Annual Salary
                    </label>
                    <div className="d-flex mb-2 pb-1">
                      <div
                        className="d-flex align-items-center"
                        style={{ maxWidth: "50%", flex: "1 0 50%" }}
                      >
                        <input
                          type="text"
                          className="frmInput mb-0 text-end"
                          style={{ width: 100 }}
                          value={state.AnnualSalaryInLakh}
                          disabled
                        />
                        <p className="frmText mb-0 text-nowrap">(₹) Lakhs</p>
                      </div>
                      <div
                        className="d-flex align-items-center"
                        style={{ maxWidth: "50%", flex: "1 0 50%" }}
                      >
                        <input
                          type="text"
                          className="frmInput mb-0 text-end"
                          style={{ width: 100 }}
                          value={state.AnnualSalaryInThousand}
                          disabled
                        />
                        <p className="frmText mb-0 text-nowrap">(₹) Thousand</p>
                      </div>
                    </div>
                  </Col>
                  <Col xs={12} md={5}>
                    <label className="frmLabel text-start mb-1 float-none">
                      Joining Date
                    </label>
                    <div className="d-flex mb-2 pb-1">
                      <div
                        className="d-flex align-items-center"
                        style={{ maxWidth: "50%", flex: "1 0 50%" }}
                        disabled
                      >
                        <select
                          className="frmInput w-auto mb-0"
                          value={state.JoiningDateInY}
                        >
                          ><option>Select</option>
                          {renderYearsOptions}
                        </select>
                        <p className="frmText mb-0 text-nowrap">Year(s)</p>
                      </div>
                      <div
                        className="d-flex align-items-center"
                        style={{ maxWidth: "50%", flex: "1 0 50%" }}
                        disabled
                      >
                        <select
                          className="frmInput w-auto mb-0"
                          value={state.JoiningDateInM}
                        >
                          <option>Select</option>
                          <option>Jan</option>
                          <option>Feb</option>
                          <option>Mar</option>
                          <option>Apr</option>
                          <option>May</option>
                          <option>Jun</option>
                          <option>Jul</option>
                          <option>Aug</option>
                          <option>Sept</option>
                          <option>Oct</option>
                          <option>Nov</option>
                          <option>Dec</option>
                        </select>
                        <p className="frmText mb-0 text-nowrap">Month(s)</p>
                      </div>
                    </div>
                  </Col>
                  <Col xs={12} md={5}>
                    <label className="frmLabel text-start mb-1 float-none">
                      Reliving Date
                    </label>
                    <div className="d-flex mb-2 pb-1">
                      <div
                        className="d-flex align-items-center"
                        style={{ maxWidth: "50%", flex: "1 0 50%" }}
                      >
                        <select
                          className="frmInput w-auto mb-0"
                          value={state.RelivingDateInY}
                        >
                          {" "}
                          disabled>
                          <option>Select</option>
                          {renderYearsOptions}
                        </select>
                        <p className="frmText mb-0 text-nowrap">Year(s)</p>
                      </div>
                      <div
                        className="d-flex align-items-center"
                        style={{ maxWidth: "50%", flex: "1 0 50%" }}
                      >
                        <select
                          className="frmInput w-auto mb-0"
                          value={state.RelivingDateInM}
                          disabled
                        >
                          <option>Select</option>
                          <option>Jan</option>
                          <option>Feb</option>
                          <option>Mar</option>
                          <option>Apr</option>
                          <option>May</option>
                          <option>Jun</option>
                          <option>Jul</option>
                          <option>Aug</option>
                          <option>Sept</option>
                          <option>Oct</option>
                          <option>Nov</option>
                          <option>Dec</option>
                        </select>
                        <p className="frmText mb-0 text-nowrap">Month(s)</p>
                      </div>
                    </div>
                  </Col>
                  <Col xs={12} md={5}>
                    <label className="frmLabel text-start mb-1 float-none">
                      Current City
                    </label>
                    <input
                      type="text"
                      placeholder="Your current city"
                      className="frmInput mb-2"
                      autoComplete="off"
                      value={state.City}
                      disabled
                    />
                  </Col>
                  <Col xs={12} md={5}>
                    <label className="frmLabel text-start mb-1 float-none">
                      Duration of Notice Period
                    </label>
                    <select
                      className="frmInput mb-0"
                      disabled
                      value={state.NoticePeriod}
                    >
                      <option>Select Duration of Notice Period</option>
                      <option>15 Days or less</option>
                      <option>1 Months</option>
                      <option>2 Months</option>
                      <option>3 Months</option>
                      <option>More than 3 Months</option>
                    </select>
                  </Col>
                </Row>
              </Col>
            </Row>
          </div>
        </div>
      </div>
    </>
  );
}
