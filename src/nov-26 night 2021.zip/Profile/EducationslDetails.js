import React,{useState,useEffect} from "react";
import Icon from "@mdi/react";
import { mdiDeleteOutline, mdiPencilOutline, mdiWindowRestore } from "@mdi/js";
import { Col } from "react-bootstrap";
import {getCandidateEducation,getCandidateeducationDelete,getAffilationDetail} from '../config/api';

export default function EducationslDetails() {
  const [cid, setCid] = useState(0);
  const [eduType, setEduType] = useState("");
  const [data, setData] = useState([]);

  useEffect(() => {
    bindData();
  }, []);
  async function bindData() {
    await getCandidateEducation(sessionStorage.getItem("CandidateID"))
      .then((response) => {
        setData(response[0]);
        
      })
      .catch((error) => {
        alert(error);
      });
  }
  
  async function deletedetail(id){
    if(window.confirm("Are you sure.?")){
    await getCandidateeducationDelete(id).then(response=>{
      alert("Deleted Successfully");
      bindData();
    }) .catch((error) => {
    alert(error);
  });
}
  }
  function updatedetail(id,education){
    setCid(id);
    setEduType(education);
  }
  const rendereducationlist=
   data.map((item,index)=>
    (
     <div className="eduListItem" key={index}>
        <h4>
         {item.Degree},
          {item.Stream}
        </h4>
        <p>{item.CollegeName}</p>
        <p>{item.StartYear} - {item.EndYear}</p>
        <p>Percentage: {item.Performance}%</p>
        <div className="eduListAction">
          <button className="edit" onClick={()=>updatedetail(item.CandidateeducationID,item.Education)}> 
            <Icon path={mdiPencilOutline} />
            edit
          </button>
          <button className="del" onClick={()=>deletedetail(item.CandidateeducationID)}>
            <Icon path={mdiDeleteOutline} />
            delete
          </button>
        </div>
      </div>));
  return (
    <>
      <div className="profileBoxDetails">
        <div className="profileBoxDetailInner">
          <div className="profileForm">
            <Col xs={12} md={12}>
              <div className="eduListItems">
              {rendereducationlist}
                {/* <div className="eduListItem">
                  <h4>
                    Bachelor of Computer Applications (BCA), Computer Science
                  </h4>
                  <p>D.N College</p>
                  <p>2020 - 2022</p>
                  <p>Percentage: 85.00%</p>
                  <div className="eduListAction">
                    <button className="edit">
                      <Icon path={mdiPencilOutline} />
                      edit
                    </button>
                    <button className="del">
                      <Icon path={mdiDeleteOutline} />
                      delete
                    </button>
                  </div>
                </div>
                <div className="eduListItem">
                  <h4>
                    Bachelor of Computer Applications (BCA), Computer Science
                  </h4>
                  <p>D.N College</p>
                  <p>2020 - 2022</p>
                  <p>Percentage: 85.00%</p>
                  <div className="eduListAction">
                    <button className="edit">
                      <Icon path={mdiPencilOutline} />
                      edit
                    </button>
                    <button className="del">
                      <Icon path={mdiDeleteOutline} />
                      delete
                    </button>
                  </div>
                </div> */}
              </div>
            </Col>
          </div>
        </div>
      </div>
    </>
  );
}
