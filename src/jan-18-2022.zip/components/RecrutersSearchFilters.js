import React from "react";
import RecrutersSearchFilterBlock from "./RecrutersSearchFilterBlock";

export default function RecrutersSearchFilters() {
  const searchLocations = [
    {
      name: "pune",
      count: 15,
    },
    {
      name: "kalyn",
      count: 11,
    },
    {
      name: "thane",
      count: 4,
    },
    {
      name: "andheri",
      count: 9,
    },
  ];
  const roles = [
    {
      name: "Recruitment /  Placement Consultant",
      count: 7,
    },
    {
      name: "Hiring Manager",
      count: 13,
    },
    {
      name: "other",
      count: 43,
    },
  ];
  const hiringFor = [
    {
      name: "HR /  Administration /  IR",
      count: 5,
    },
    {
      name: "IT Software - Application Programming /  Maintenance",
      count: 4,
    },
    {
      name: "ITES /  BPO /  KPO /  Customer Service /  Operations",
      count: 3,
    },
    {
      name: "IT Software - DBA /  Datawarehousing",
      count: 2,
    },
    {
      name: "IT Software - System Programming",
      count: 2,
    },
  ];
  const Levels = [
    {
      name: "Senior Management",
      count: 12,
    },
    {
      name: "Top Mangement",
      count: 9,
    },
  ];
  return (
    <>
      <div className="search-filters">
        <RecrutersSearchFilterBlock
          items={searchLocations}
          title="Recruiter's Location"
        />
        <RecrutersSearchFilterBlock items={roles} title="Recruiter's Role" />
        <RecrutersSearchFilterBlock
          items={hiringFor}
          title="Functions Hiring For"
        />
        <RecrutersSearchFilterBlock items={Levels} title="Levels Hiring For" />
      </div>
    </>
  );
}
