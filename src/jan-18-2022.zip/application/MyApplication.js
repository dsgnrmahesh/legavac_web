import React from "react";

export default function MyApplication() {
  return (
    <>
      <div className="app__spacer"></div>
      <section className="app__section form-section py-5">
        my application
      </section>
    </>
  );
}
